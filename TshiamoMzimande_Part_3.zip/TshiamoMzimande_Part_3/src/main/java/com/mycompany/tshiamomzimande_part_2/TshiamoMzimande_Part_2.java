package com.mycompany.tshiamomzimande_part_2;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class TshiamoMzimande_Part_2 {
    
    // Part 3 Required Arrays (no hard-coding)
    private static ArrayList<String> sentMessages = new ArrayList<>();        // Contains all messages sent
    private static ArrayList<String> disregardedMessages = new ArrayList<>();  // Contains all disregarded messages
    private static ArrayList<Map<String, Object>> storedMessages = new ArrayList<>(); // Contains stored messages from JSON
    private static ArrayList<String> messageHashes = new ArrayList<>();       // Contains all message hashes
    private static ArrayList<String> messageIds = new ArrayList<>();          // Contains all message IDs
    
    // Original arrays for backward compatibility
    private static ArrayList<String> storedIds = new ArrayList<>();
    private static ArrayList<String> storedHashes = new ArrayList<>();
    private static ArrayList<String> storedRecipients = new ArrayList<>();
    private static ArrayList<String> storedMessagesContent = new ArrayList<>();
    private static ArrayList<String> storedStatus = new ArrayList<>();
    
    private static Scanner input = new Scanner(System.in);
    
    // SA phone number regex
    private static final Pattern SA_PATTERN = Pattern.compile("^((\\+27)|0)[678][0-9]{8}$");
    
    // JSON file storage
    private static final String JSON_FILE = "messages.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    
    // User credentials
    private static String savedUser = "";
    private static String savedPass = "";
    private static boolean userRegistered = false;
    
    public static void main(String[] args) {
        System.out.println("WELCOME TO CHATTER");
        
        boolean loggedIntoSystem = false;
        
        while (!loggedIntoSystem) {
            showMainOptions();
            String userDecision = input.nextLine();
            
            switch (userDecision) {
                case "1":
                    createNewAccount();
                    break;
                case "2":
                    if (userRegistered) {
                        loggedIntoSystem = verifyLogin();
                    } else {
                        System.out.println("No account found. Please register first.");
                    }
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid selection. Try again.");
            }
        }
        
        // Load test data from document
        loadTestData();
        
        startMessagingSystem();
    }
    
    // Load test data as specified in the document
    private static void loadTestData() {
        System.out.println("\n=== LOADING TEST DATA ===");
        
        // Test Data Message 1 - Sent
        processTestData("+27834557896", "Did you get the cake?", "Sent");
        
        // Test Data Message 2 - Stored
        processTestData("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        
        // Test Data Message 3 - Disregard
        processTestData("+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        
        // Test Data Message 4 - Sent (Developer entry)
        processTestData("0838884567", "It is dinner time!", "Sent");
        
        // Test Data Message 5 - Stored
        processTestData("+27838884567", "Ok, I am leaving without you.", "Stored");
        
        System.out.println("Test data loaded successfully!");
        System.out.println("Sent Messages: " + sentMessages.size());
        System.out.println("Stored Messages: " + storedMessages.size());
        System.out.println("Disregarded Messages: " + disregardedMessages.size());
    }
    
    private static void processTestData(String recipient, String message, String flag) {
        String msgId = generateMessageId();
        String msgHash = generateMessageHash(message, msgId);
        
        // Populate required arrays
        messageIds.add(msgId);
        messageHashes.add(msgHash);
        
        // Create stored message object
        Map<String, Object> storedMsg = new HashMap<>();
        storedMsg.put("message_id", msgId);
        storedMsg.put("hash", msgHash);
        storedMsg.put("recipient", recipient);
        storedMsg.put("message", message);
        storedMsg.put("flag", flag);
        
        if (flag.equalsIgnoreCase("Sent")) {
            sentMessages.add(message);
            storedMessages.add(storedMsg);
        } else if (flag.equalsIgnoreCase("Disregard")) {
            disregardedMessages.add(message);
        } else if (flag.equalsIgnoreCase("Stored")) {
            storedMessages.add(storedMsg);
        }
    }
    
    private static String generateMessageId() {
        Random rand = new Random();
        return String.valueOf(1000000000L + (long)(rand.nextDouble() * 9000000000L));
    }
    
    private static String generateMessageHash(String message, String messageId) {
        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^A-Za-z]", "").toUpperCase() : "";
        String lastWord = words.length > 1 ? words[words.length - 1].replaceAll("[^A-Za-z]", "").toUpperCase() : firstWord;
        String idPrefix = messageId.substring(0, 2);
        return idPrefix + ":" + firstWord + lastWord;
    }
    
    private static void showMainOptions() {
        System.out.println("\n[MAIN MENU]");
        System.out.println("1. Create New Account");
        System.out.println("2. Sign In");
        System.out.println("3. Exit Application");
        System.out.print("Choose an option: ");
    }
    
    private static void createNewAccount() {
        System.out.println("\nREGISTRATION FORM");
        System.out.print("Choose username: ");
        savedUser = input.nextLine();
        System.out.print("Choose password: ");
        savedPass = input.nextLine();
        userRegistered = true;
        System.out.println("Account created successfully!");
    }
    
    private static boolean verifyLogin() {
        System.out.println("\nLOGIN SCREEN");
        System.out.print("Username: ");
        String enteredUser = input.nextLine();
        System.out.print("Password: ");
        String enteredPass = input.nextLine();
        
        if (enteredUser.equals(savedUser) && enteredPass.equals(savedPass)) {
            System.out.println("Access granted!");
            return true;
        } else {
            System.out.println("Access denied. Incorrect credentials.");
            return false;
        }
    }
    
    private static void startMessagingSystem() {
        System.out.println("\nWelcome to Chatter Messaging System");
        
        int msgLimit = 0;
        while (msgLimit <= 0) {
            System.out.print("How many messages would you like to create? ");
            try {
                msgLimit = Integer.parseInt(input.nextLine());
                if (msgLimit <= 0) {
                    System.out.println("Please enter a number greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Try again.");
            }
        }
        
        int sentTotal = 0;
        int storedTotal = 0;
        int discardedTotal = 0;
        
        boolean appRunning = true;
        while (appRunning) {
            showMessagingMenu();
            String menuPick = input.nextLine();
            
            switch (menuPick) {
                case "1":
                    for (int cycle = 0; cycle < msgLimit; cycle++) {
                        System.out.println("\nMESSAGE " + (cycle + 1) + " of " + msgLimit);
                        
                        String phoneNumber = capturePhoneNumber();
                        String messageBody = captureMessageContent();
                        
                        ChatterMessage newMsg = new ChatterMessage(cycle + 1, phoneNumber, messageBody);
                        
                        displayPreview(newMsg);
                        
                        String userAction = getUserAction();
                        System.out.println(userAction);
                        
                        if (userAction.equals("Message sent successfully!")) {
                            // Add to sent messages array
                            sentMessages.add(newMsg.getText());
                            messageIds.add(newMsg.getMessageId());
                            messageHashes.add(newMsg.getMessageHash());
                            
                            Map<String, Object> storedMsg = new HashMap<>();
                            storedMsg.put("message_id", newMsg.getMessageId());
                            storedMsg.put("hash", newMsg.getMessageHash());
                            storedMsg.put("recipient", newMsg.getRecipient());
                            storedMsg.put("message", newMsg.getText());
                            storedMsg.put("flag", "Sent");
                            storedMessages.add(storedMsg);
                            
                            sentTotal++;
                            
                        } else if (userAction.equals("Message discarded.")) {
                            // Add to disregarded messages array
                            disregardedMessages.add(messageBody);
                            discardedTotal++;
                            
                        } else if (userAction.equals("Message saved to storage.")) {
                            // Add to stored messages
                            messageIds.add(newMsg.getMessageId());
                            messageHashes.add(newMsg.getMessageHash());
                            
                            Map<String, Object> storedMsg = new HashMap<>();
                            storedMsg.put("message_id", newMsg.getMessageId());
                            storedMsg.put("hash", newMsg.getMessageHash());
                            storedMsg.put("recipient", newMsg.getRecipient());
                            storedMsg.put("message", newMsg.getText());
                            storedMsg.put("flag", "Stored");
                            storedMessages.add(storedMsg);
                            
                            newMsg.archiveToJson();
                            storedTotal++;
                        }
                    }
                    
                    printFinalSummary(sentTotal, storedTotal, discardedTotal, msgLimit);
                    
                    System.out.print("\nPress Enter to continue or type 'quit' to exit: ");
                    String continueChoice = input.nextLine();
                    if (continueChoice.equalsIgnoreCase("quit")) {
                        appRunning = false;
                    }
                    break;
                    
                case "2":
                    viewRecentMessages();
                    break;
                    
                case "3":
                    System.out.println("Logging out. Goodbye!");
                    appRunning = false;
                    break;
                    
                case "4":
                    // FOURTH MAIN MENU OPTION FOR STORED MESSAGES
                    storedMessagesMenu();
                    break;
                    
                default:
                    System.out.println("Invalid option. Please choose 1, 2, 3, or 4.");
            }
        }
        
        input.close();
    }
    
    // FOURTH MAIN MENU OPTION - Stored Messages Menu
    private static void storedMessagesMenu() {
        boolean backToMain = false;
        while (!backToMain) {
            System.out.println("\n+=============================================+");
            System.out.println("|           STORED MESSAGES MENU              |");
            System.out.println("+=============================================+");
            System.out.println("| 1. Display sender and recipient             |");
            System.out.println("| 2. Display the longest stored message       |");
            System.out.println("| 3. Search for a message ID                  |");
            System.out.println("| 4. Search by recipient                      |");
            System.out.println("| 5. Delete a message using message hash      |");
            System.out.println("| 6. Display full report                      |");
            System.out.println("| 7. Return to Main Menu                      |");
            System.out.println("+=============================================+");
            System.out.print("Select option: ");
            
            String choice = input.nextLine();
            
            switch (choice) {
                case "1":
                    displaySenderAndRecipient();
                    break;
                case "2":
                    displayLongestStoredMessage();
                    break;
                case "3":
                    searchByMessageId();
                    break;
                case "4":
                    searchByRecipient();
                    break;
                case "5":
                    deleteByMessageHash();
                    break;
                case "6":
                    displayFullReport();
                    break;
                case "7":
                    backToMain = true;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    // 2a: Display sender and recipient of all stored messages
    private static void displaySenderAndRecipient() {
        System.out.println("\n=== SENDER AND RECIPIENT OF ALL STORED MESSAGES ===");
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        
        System.out.printf("%-20s %-20s %-50s%n", "SENDER (FLAG)", "RECIPIENT", "MESSAGE");
        System.out.println("--------------------------------------------------------------------------------");
        
        for (Map<String, Object> msg : storedMessages) {
            String sender = (String) msg.get("flag");
            String recipient = (String) msg.get("recipient");
            String message = (String) msg.get("message");
            
            if (message.length() > 47) {
                message = message.substring(0, 44) + "...";
            }
            
            System.out.printf("%-20s %-20s %-50s%n", sender, recipient, message);
        }
    }
    
    // 2b: Display the longest stored message
    private static void displayLongestStoredMessage() {
        System.out.println("\n=== LONGEST STORED MESSAGE ===");
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        
        Map<String, Object> longestMsg = null;
        int maxLength = 0;
        
        for (Map<String, Object> msg : storedMessages) {
            String message = (String) msg.get("message");
            if (message.length() > maxLength) {
                maxLength = message.length();
                longestMsg = msg;
            }
        }
        
        if (longestMsg != null) {
            System.out.println("Recipient: " + longestMsg.get("recipient"));
            System.out.println("Message: \"" + longestMsg.get("message") + "\"");
            System.out.println("Length: " + maxLength + " characters");
        }
    }
    
    // 2c: Search for a message ID and display recipient and message
    private static void searchByMessageId() {
        System.out.println("\n=== SEARCH FOR MESSAGE ID ===");
        System.out.print("Enter Message ID to search: ");
        String searchId = input.nextLine();
        
        boolean found = false;
        for (Map<String, Object> msg : storedMessages) {
            if (msg.get("message_id").equals(searchId)) {
                System.out.println("\n✓ Message Found!");
                System.out.println("Recipient: " + msg.get("recipient"));
                System.out.println("Message: \"" + msg.get("message") + "\"");
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("No message found with ID: " + searchId);
        }
    }
    
    // 2d: Search for all messages stored for a particular recipient
    private static void searchByRecipient() {
        System.out.println("\n=== SEARCH FOR MESSAGES BY RECIPIENT ===");
        System.out.print("Enter recipient number to search: ");
        String searchRecipient = input.nextLine();
        
        boolean found = false;
        System.out.println("\nMessages for recipient: " + searchRecipient);
        System.out.println("----------------------------------------");
        
        for (Map<String, Object> msg : storedMessages) {
            if (msg.get("recipient").equals(searchRecipient)) {
                System.out.println("• \"" + msg.get("message") + "\"");
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No messages found for recipient: " + searchRecipient);
        }
    }
    
    // 2e: Delete a message using the message hash
    private static void deleteByMessageHash() {
        System.out.println("\n=== DELETE MESSAGE BY HASH ===");
        System.out.print("Enter Message Hash to delete: ");
        String searchHash = input.nextLine();
        
        boolean found = false;
        Iterator<Map<String, Object>> iterator = storedMessages.iterator();
        
        while (iterator.hasNext()) {
            Map<String, Object> msg = iterator.next();
            if (msg.get("hash").equals(searchHash)) {
                System.out.println("\n✓ Message successfully deleted!");
                System.out.println("Message: \"" + msg.get("message") + "\"");
                iterator.remove();
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("No message found with hash: " + searchHash);
        }
    }
    
    // 2f: Display report with full details of all stored messages
    private static void displayFullReport() {
        System.out.println("\n+================================================================================+");
        System.out.println("|                         COMPLETE STORED MESSAGES REPORT                       |");
        System.out.println("+================================================================================+");
        
        if (storedMessages.isEmpty()) {
            System.out.println("|                        NO STORED MESSAGES AVAILABLE                           |");
            System.out.println("+================================================================================+");
            return;
        }
        
        System.out.printf("%-20s %-20s %-15s %-40s%n", "MESSAGE HASH", "RECIPIENT", "MESSAGE ID", "MESSAGE");
        System.out.println("--------------------------------------------------------------------------------");
        
        for (Map<String, Object> msg : storedMessages) {
            String hash = (String) msg.get("hash");
            String recipient = (String) msg.get("recipient");
            String msgId = (String) msg.get("message_id");
            String message = (String) msg.get("message");
            
            if (message.length() > 37) {
                message = message.substring(0, 34) + "...";
            }
            
            System.out.printf("%-20s %-20s %-15s %-40s%n", hash, recipient, msgId, message);
        }
        
        System.out.println("+================================================================================+");
        System.out.println("Total Stored Messages: " + storedMessages.size());
        System.out.println("Total Sent Messages: " + sentMessages.size());
        System.out.println("Total Disregarded Messages: " + disregardedMessages.size());
        System.out.println("+================================================================================+");
    }
    
    private static void viewRecentMessages() {
        System.out.println("\n=== RECENT MESSAGES ===");
        if (storedMessages.isEmpty()) {
            System.out.println("No messages to display.");
            return;
        }
        
        for (int i = 0; i < storedMessages.size(); i++) {
            Map<String, Object> msg = storedMessages.get(i);
            System.out.println("\nMessage " + (i + 1));
            System.out.println("  ID: " + msg.get("message_id"));
            System.out.println("  Hash: " + msg.get("hash"));
            System.out.println("  Recipient: " + msg.get("recipient"));
            System.out.println("  Message: " + msg.get("message"));
            System.out.println("  Flag: " + msg.get("flag"));
        }
    }
    
    private static void showMessagingMenu() {
        System.out.println("\n[CHATTER MENU]");
        System.out.println("1. Compose & Send Message");
        System.out.println("2. View Recent Messages");
        System.out.println("3. Exit Application");
        System.out.println("4. Stored Messages Menu"); // Fourth menu option
        System.out.print("Your selection: ");
    }
    
    private static String capturePhoneNumber() {
        String number = "";
        boolean valid = false;
        
        while (!valid) {
            System.out.print("Recipient's SA number (e.g., 0712345678): ");
            number = input.nextLine();
            String cleaned = number.replaceAll("[\\s-]", "");
            
            if (SA_PATTERN.matcher(cleaned).matches()) {
                valid = true;
            } else {
                System.out.println("Invalid format! Use 0712345678 or +27712345678");
            }
        }
        return number;
    }
    
    private static String captureMessageContent() {
        String msg = "";
        boolean good = false;
        
        while (!good) {
            System.out.print("Type your message (max 250 characters): ");
            msg = input.nextLine();
            
            if (msg.length() <= 250) {
                good = true;
            } else {
                int extra = msg.length() - 250;
                System.out.println("Too long! Exceeds by " + extra + " characters. Please shorten.");
            }
        }
        return msg;
    }
    
    private static void displayPreview(ChatterMessage msg) {
        System.out.println("\n[MESSAGE PREVIEW]");
        System.out.println(msg.previewMessage());
    }
    
    private static String getUserAction() {
        System.out.println("\n[OPTIONS FOR MESSAGE]");
        System.out.println("1. Send immediately");
        System.out.println("2. Throw away");
        System.out.println("3. Save for later (JSON)");
        System.out.print("Pick an option (1-3): ");
        
        String decision = input.nextLine();
        
        switch (decision) {
            case "1": return "Message sent successfully!";
            case "2": return "Message discarded.";
            case "3": return "Message saved to storage.";
            default: return "Invalid. Please try again.";
        }
    }
    
    private static void printFinalSummary(int sent, int stored, int discarded, int total) {
        System.out.println("\n[FINAL REPORT]");
        System.out.println("Messages sent:      " + sent);
        System.out.println("Messages stored:    " + stored);
        System.out.println("Messages discarded: " + discarded);
        System.out.println("Total processed:    " + total);
    }
    
    // ==================== INNER CLASS ====================
    
    static class ChatterMessage {
        private String uid;
        private int sequence;
        private String destination;
        private String content;
        private String securityHash;
        private String condition;
        
        public ChatterMessage(int seq, String phone, String msg) {
            this.sequence = seq;
            this.destination = phone;
            this.content = msg;
            this.uid = createUniqueId();
            this.securityHash = generateHashCode();
            this.condition = "draft";
        }
        
        private String createUniqueId() {
            Random rand = new Random();
            long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
            return String.valueOf(id);
        }
        
        private String generateHashCode() {
            String prefix = this.uid.substring(0, 2);
            String[] words = this.content.trim().split("\\W+");
            String first = words.length > 0 ? words[0].toUpperCase() : "";
            String last = words.length > 1 ? words[words.length-1].toUpperCase() : first;
            return prefix + ":" + this.sequence + ":" + first + last;
        }
        
        public String previewMessage() {
            return "ID: " + this.uid + "\n" +
                   "Hash: " + this.securityHash + "\n" +
                   "To: " + this.destination + "\n" +
                   "Msg: " + this.content;
        }
        
        public void archiveToJson() {
            try {
                List<Map<String, Object>> messageArchive = new ArrayList<>();
                File jsonFile = new File(JSON_FILE);
                
                if (jsonFile.exists()) {
                    String existingContent = new String(Files.readAllBytes(Paths.get(JSON_FILE)));
                    if (!existingContent.trim().isEmpty()) {
                        messageArchive = gson.fromJson(existingContent, new TypeToken<List<Map<String, Object>>>(){}.getType());
                    }
                }
                
                Map<String, Object> messageRecord = new LinkedHashMap<>();
                messageRecord.put("messageId", this.uid);
                messageRecord.put("messageNumber", this.sequence);
                messageRecord.put("messageHash", this.securityHash);
                messageRecord.put("recipient", this.destination);
                messageRecord.put("message", this.content);
                messageRecord.put("status", this.condition);
                messageRecord.put("timestamp", new Date().toString());
                
                messageArchive.add(messageRecord);
                
                String jsonOutput = gson.toJson(messageArchive);
                Files.write(Paths.get(JSON_FILE), jsonOutput.getBytes());
                
                System.out.println("JSON file saved to: " + new File(JSON_FILE).getAbsolutePath());
                
            } catch (IOException e) {
                System.out.println("Error saving to JSON: " + e.getMessage());
            }
        }
        
        public String getMessageId() { return uid; }
        public String getMessageHash() { return securityHash; }
        public String getRecipient() { return destination; }
        public String getText() { return content; }
        public String getStatus() { return condition; }
    }
}
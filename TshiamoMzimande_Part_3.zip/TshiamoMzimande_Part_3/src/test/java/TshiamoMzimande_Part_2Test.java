import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class TshiamoMzimande_Part_2Test {
    
    // Test data arrays for Part 3
    private List<String> sentMessages;
    private List<String> disregardedMessages;
    private List<Map<String, Object>> storedMessages;
    private List<String> messageHashes;
    private List<String> messageIds;
    
    public TshiamoMzimande_Part_2Test() {
        sentMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        messageHashes = new ArrayList<>();
        messageIds = new ArrayList<>();
    }
    
    @BeforeClass
    public static void setupSuite() {
        System.out.println("=========================================");
        System.out.println("   CHATTER SYSTEM - PART 3 UNIT TESTS");
        System.out.println("=========================================");
    }
    
    @AfterClass
    public static void teardownSuite() {
        System.out.println("\n=========================================");
        System.out.println("         ALL TESTS COMPLETED");
        System.out.println("=========================================");
    }
    
    @Before
    public void beforeEach() {
        System.out.println("\n> Running test...");
    }
    
    @After
    public void afterEach() {
        System.out.println("< Test finished.");
    }
    
    // ==================== REQUIRED TESTS FROM DOCUMENT ====================
    
    // TEST 1: Sent Messages array correctly populated (assertEquals)
    @Test
    public void testSentMessagesArrayPopulated() {
        System.out.println("\n[TEST 1] Sent Messages array correctly populated");
        
        // Load test data messages 1-4
        sentMessages.add("Did you get the cake?");
        sentMessages.add("It is dinner time!");
        
        System.out.println("   Test Data: Developer entry for Test data for message 1-4");
        System.out.println("   Expected: \"Did you get the cake?\", \"It is dinner time!\"");
        System.out.println("   Actual: " + sentMessages);
        
        assertEquals(2, sentMessages.size());
        assertEquals("Did you get the cake?", sentMessages.get(0));
        assertEquals("It is dinner time!", sentMessages.get(1));
        
        System.out.println("   ✓ The Messages array contains the expected test data");
    }
    
    // TEST 2: Display the longest Message (assertEquals)
    @Test
    public void testLongestMessage() {
        System.out.println("\n[TEST 2] Display the longest Message");
        
        // Test data messages 1-4
        List<String> testMessages = Arrays.asList(
            "Did you get the cake?",
            "Where are you? You are late! I have asked you to be on time.",
            "Yohoooo, I am at your gate.",
            "It is dinner time!"
        );
        
        String longest = "";
        for (String msg : testMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        
        String expected = "Where are you? You are late! I have asked you to be on time.";
        
        System.out.println("   Test Data: message 1-4");
        System.out.println("   Expected: \"" + expected + "\"");
        System.out.println("   Actual: \"" + longest + "\"");
        
        assertEquals(expected, longest);
        System.out.println("   ✓ Longest message correctly identified");
    }
    
    // TEST 3: Search for messageID (assertEquals)
    @Test
    public void testSearchByMessageId() {
        System.out.println("\n[TEST 3] Search for messageID");
        
        // Test data message 4
        Map<String, Object> testMessage = new HashMap<>();
        testMessage.put("message_id", "0838884567");
        testMessage.put("recipient", "0838884567");
        testMessage.put("message", "It is dinner time!");
        
        String searchId = "0838884567";
        String foundRecipient = "";
        String foundMessage = "";
        
        if (testMessage.get("message_id").equals(searchId)) {
            foundRecipient = (String) testMessage.get("recipient");
            foundMessage = (String) testMessage.get("message");
        }
        
        System.out.println("   Test Data: message 4");
        System.out.println("   Searching for ID: " + searchId);
        System.out.println("   Found Recipient: " + foundRecipient);
        System.out.println("   Found Message: \"" + foundMessage + "\"");
        
        assertEquals("0838884567", foundRecipient);
        assertEquals("It is dinner time!", foundMessage);
        
        System.out.println("   ✓ Message ID search successful");
    }
    
    // TEST 4: Search all the messages regarding a particular recipient (assertEquals)
    @Test
    public void testSearchByRecipient() {
        System.out.println("\n[TEST 4] Search all messages for a particular recipient");
        
        // Test data for recipient +27838884567 (messages 2 and 5)
        List<String> recipientMessages = new ArrayList<>();
        recipientMessages.add("Where are you? You are late! I have asked you to be on time.");
        recipientMessages.add("Ok, I am leaving without you.");
        
        String searchRecipient = "+27838884567";
        
        System.out.println("   Test Data: +27838884567");
        System.out.println("   Searching for recipient: " + searchRecipient);
        System.out.println("   Found messages:");
        for (String msg : recipientMessages) {
            System.out.println("     \"" + msg + "\"");
        }
        
        assertEquals(2, recipientMessages.size());
        assertTrue(recipientMessages.get(0).contains("Where are you?"));
        assertTrue(recipientMessages.get(1).contains("Ok, I am leaving"));
        
        System.out.println("   ✓ Recipient search successful");
    }
    
    // TEST 5: Delete a message using a message hash (assertEquals)
    @Test
    public void testDeleteByMessageHash() {
        System.out.println("\n[TEST 5] Delete a message using a message hash");
        
        // Test data message 2
        List<Map<String, Object>> messageStore = new ArrayList<>();
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("hash", "TEST:HASH:123");
        msg2.put("message", "Where are you? You are late! I have asked you to be on time");
        messageStore.add(msg2);
        
        String deleteHash = "TEST:HASH:123";
        boolean deleted = false;
        String deletedMessage = "";
        
        Iterator<Map<String, Object>> iterator = messageStore.iterator();
        while (iterator.hasNext()) {
            Map<String, Object> msg = iterator.next();
            if (msg.get("hash").equals(deleteHash)) {
                deletedMessage = (String) msg.get("message");
                iterator.remove();
                deleted = true;
                break;
            }
        }
        
        System.out.println("   Test Data: Test Message 2");
        System.out.println("   Deleting hash: " + deleteHash);
        System.out.println("   Deleted message: \"" + deletedMessage + "\"");
        System.out.println("   Deletion successful: " + deleted);
        
        assertTrue(deleted);
        assertEquals("Where are you? You are late! I have asked you to be on time", deletedMessage);
        assertEquals(0, messageStore.size());
        
        System.out.println("   ✓ Message successfully deleted");
    }
    
    // TEST 6: Display Report (Verify report contains Message Hash, Recipient, Message)
    @Test
    public void testDisplayReport() {
        System.out.println("\n[TEST 6] Display Report verification");
        
        // Create test stored messages
        List<Map<String, Object>> reportData = new ArrayList<>();
        Map<String, Object> msg1 = new HashMap<>();
        msg1.put("hash", "00:GETCAKE");
        msg1.put("recipient", "+27834557896");
        msg1.put("message", "Did you get the cake?");
        reportData.add(msg1);
        
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("hash", "01:WHEREON");
        msg2.put("recipient", "+27838884567");
        msg2.put("message", "Where are you? You are late!");
        reportData.add(msg2);
        
        System.out.println("   Display Report Output:");
        System.out.println("   ================================================");
        System.out.printf("   %-15s %-15s %-30s%n", "MESSAGE HASH", "RECIPIENT", "MESSAGE");
        System.out.println("   ------------------------------------------------");
        for (Map<String, Object> msg : reportData) {
            System.out.printf("   %-15s %-15s %-30s%n", msg.get("hash"), msg.get("recipient"), msg.get("message"));
        }
        System.out.println("   ================================================");
        
        assertFalse("Report should not be empty", reportData.isEmpty());
        assertEquals(2, reportData.size());
        
        // Verify report contains required fields
        assertNotNull(msg1.get("hash"));
        assertNotNull(msg1.get("recipient"));
        assertNotNull(msg1.get("message"));
        
        System.out.println("   ✓ Report shows Message Hash, Recipient, and Message");
    }
    
    // TEST 7: Verify Stored Messages array from JSON
    @Test
    public void testStoredMessagesFromJson() {
        System.out.println("\n[TEST 7] Stored Messages array from JSON");
        
        // Simulate loading from JSON
        List<Map<String, Object>> jsonMessages = new ArrayList<>();
        Map<String, Object> storedMsg = new HashMap<>();
        storedMsg.put("message_id", "MSG001");
        storedMsg.put("recipient", "+27838884567");
        storedMsg.put("message", "Where are you? You are late! I have asked you to be on time.");
        storedMsg.put("flag", "Stored");
        jsonMessages.add(storedMsg);
        
        System.out.println("   Messages loaded from JSON: " + jsonMessages.size());
        
        assertNotNull("Stored messages array should not be null", jsonMessages);
        assertEquals(1, jsonMessages.size());
        
        System.out.println("   ✓ Stored Messages array correctly populated from JSON");
    }
    
    // TEST 8: Verify Message Hash array contents
    @Test
    public void testMessageHashArray() {
        System.out.println("\n[TEST 8] Message Hash array verification");
        
        // Add hashes for test messages
        messageHashes.add("00:GETCAKE");
        messageHashes.add("01:WHEREON");
        messageHashes.add("02:YOHOGATE");
        messageHashes.add("03:ITDINNER");
        messageHashes.add("04:OKYOU");
        
        System.out.println("   Message Hash array contents:");
        for (int i = 0; i < messageHashes.size(); i++) {
            System.out.println("     [" + i + "] " + messageHashes.get(i));
        }
        
        assertEquals(5, messageHashes.size());
        
        // Verify each hash contains colon separator
        for (String hash : messageHashes) {
            assertTrue(hash.contains(":"));
        }
        
        System.out.println("   ✓ Message Hash array correctly populated");
    }
    
    // TEST 9: Verify Message ID array contents
    @Test
    public void testMessageIdArray() {
        System.out.println("\n[TEST 9] Message ID array verification");
        
        // Add IDs for test messages
        messageIds.add("1000000001");
        messageIds.add("1000000002");
        messageIds.add("1000000003");
        messageIds.add("1000000004");
        messageIds.add("1000000005");
        
        System.out.println("   Message ID array contents:");
        for (int i = 0; i < messageIds.size(); i++) {
            System.out.println("     [" + i + "] " + messageIds.get(i));
        }
        
        assertEquals(5, messageIds.size());
        
        // Verify each ID is 10 digits
        for (String id : messageIds) {
            assertEquals(10, id.length());
            assertTrue(id.matches("\\d+"));
        }
        
        System.out.println("   ✓ Message ID array correctly populated");
    }
    
    // TEST 10: Verify Disregarded Messages array
    @Test
    public void testDisregardedMessagesArray() {
        System.out.println("\n[TEST 10] Disregarded Messages array verification");
        
        // Test data message 3 is disregarded
        disregardedMessages.add("Yohoooo, I am at your gate.");
        
        System.out.println("   Disregarded messages: " + disregardedMessages);
        
        assertEquals(1, disregardedMessages.size());
        assertEquals("Yohoooo, I am at your gate.", disregardedMessages.get(0));
        
        System.out.println("   ✓ Disregarded Messages array correctly populated");
    }
    
    // TEST 11: Verify all required arrays exist and are populated
    @Test
    public void testAllRequiredArrays() {
        System.out.println("\n[TEST 11] All required arrays verification");
        
        // Populate all required arrays
        sentMessages.add("Did you get the cake?");
        disregardedMessages.add("Yohoooo, I am at your gate.");
        messageHashes.add("00:GETCAKE");
        messageIds.add("1000000001");
        
        Map<String, Object> stored = new HashMap<>();
        stored.put("message", "Test stored message");
        storedMessages.add(stored);
        
        System.out.println("   Sent Messages array size: " + sentMessages.size());
        System.out.println("   Disregarded Messages array size: " + disregardedMessages.size());
        System.out.println("   Stored Messages array size: " + storedMessages.size());
        System.out.println("   Message Hash array size: " + messageHashes.size());
        System.out.println("   Message ID array size: " + messageIds.size());
        
        assertNotNull("Sent Messages array should exist", sentMessages);
        assertNotNull("Disregarded Messages array should exist", disregardedMessages);
        assertNotNull("Stored Messages array should exist", storedMessages);
        assertNotNull("Message Hash array should exist", messageHashes);
        assertNotNull("Message ID array should exist", messageIds);
        
        System.out.println("   ✓ All required arrays are present and populated");
    }
    
    // TEST 12: Verify sender and recipient display
    @Test
    public void testDisplaySenderAndRecipient() {
        System.out.println("\n[TEST 12] Display sender and recipient verification");
        
        List<Map<String, Object>> testData = new ArrayList<>();
        Map<String, Object> msg1 = new HashMap<>();
        msg1.put("flag", "Sent");
        msg1.put("recipient", "+27834557896");
        msg1.put("message", "Did you get the cake?");
        testData.add(msg1);
        
        Map<String, Object> msg2 = new HashMap<>();
        msg2.put("flag", "Stored");
        msg2.put("recipient", "+27838884567");
        msg2.put("message", "Where are you?");
        testData.add(msg2);
        
        System.out.println("   Sender and Recipient Display:");
        for (Map<String, Object> msg : testData) {
            System.out.println("   Sender: " + msg.get("flag") + " | Recipient: " + msg.get("recipient") + " | Message: " + msg.get("message"));
        }
        
        assertEquals(2, testData.size());
        assertEquals("Sent", testData.get(0).get("flag"));
        assertEquals("+27834557896", testData.get(0).get("recipient"));
        
        System.out.println("   ✓ Display sender and recipient working correctly");
    }
}